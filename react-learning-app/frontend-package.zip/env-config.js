window._env_ = {
  VITE_API_URL: "https://chinesemaster-dwffc2hrdpfdh3dz.southeastasia-01.azurewebsites.net/api",
  REACT_APP_API_URL: "https://chinesemaster-dwffc2hrdpfdh3dz.southeastasia-01.azurewebsites.net/api",
  VITE_CLOUDINARY_PINYIN_AUDIO_BASE_URL:
    "https://res.cloudinary.com/dtshwjjbc/video/upload/v1760853479/chinese-master/pinyin-audio",
};
